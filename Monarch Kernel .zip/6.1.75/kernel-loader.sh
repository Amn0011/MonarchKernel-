#!/bin/bash

# Set terminal colors for better readability
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo "===== Join us on tg at @hiji_didi ====="
echo "===== Android Kernel Loader ====="
echo "Attempting to load kernel module from current directory..."

# Check if kernel file exists in current directory
if [ ! -f "./kernel" ]; then
    echo -e "${RED}Error: kernel file not found in current directory${NC}"
    echo "Please make sure the kernel file exists and is named 'kernel'"
    exit 1
fi

# Try to load the kernel module with root permissions
echo "Executing: su -c insmod ./kernel"
RESULT=$(su -c insmod ./kernel 2>&1)
EXIT_CODE=$?

# Check if the command was successful
if [ $EXIT_CODE -eq 0 ]; then
    echo -e "${GREEN}Success: Kernel module loaded successfully!${NC}"
    # Check if the module is loaded
    LOADED_CHECK=$(lsmod | grep kernel)
    if [ -n "$LOADED_CHECK" ]; then
        echo "Module details: $LOADED_CHECK"
    fi
else
    echo -e "${RED}Failed to load kernel module.${NC}"
    echo -e "${YELLOW}Error message:${NC} $RESULT"
    
    # Check if it's a permission issue
    if [[ "$RESULT" == *"Permission denied"* ]]; then
        echo -e "${YELLOW}This appears to be a permission issue. Make sure:${NC}"
        echo "  1. Your device is rooted"
        echo "  2. You granted root access to the terminal app"
    fi
    
    # Check if module is already loaded
    if [[ "$RESULT" == *"File exists"* ]]; then
        echo -e "${YELLOW}The kernel module appears to be already loaded.${NC}"
        echo "You can check loaded modules with: su -c lsmod | grep kernel"
    fi
    
    # Check for invalid format
    if [[ "$RESULT" == *"Invalid module format"* ]]; then
        echo -e "${YELLOW}The kernel file appears to be incompatible with your device.${NC}"
        echo "Make sure the kernel module was compiled for your specific device and Android version."
    fi
fi

echo "===== Operation Complete ====="
