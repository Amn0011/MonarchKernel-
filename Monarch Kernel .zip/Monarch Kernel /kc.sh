#!/bin/bash

# Simple script to run the ./fs command
# Usage: ./run_fs.sh
echo "===== Join us on tg at @hiji_didi ====="
echo "Running fs command..."

# Check if the fs file exists and is executable
if [ -f "./kc" ]; then
    if [ -x "./kc" ]; then
        # Execute the fs command
         ./kc
        
        # Capture the exit status
        exit_status=$?
        
        # Output the result based on exit status
        if [ $exit_status -eq 0 ]; then
            echo "fs command completed successfully."
        else
            echo "fs command failed with exit status: $exit_status"
        fi
    else
        echo "Error: fs file is not executable. Try running: chmod +x ./kc"
        exit 1
    fi
else
    echo "Error: kc file not found in the current directory."
    exit 1
fi
